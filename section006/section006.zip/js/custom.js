const BTN = document.querySelector('#btn');
const H1 = document.querySelector('h1');

BTN.addEventListener('click', function () {
    H1.style.display = 'none';
});